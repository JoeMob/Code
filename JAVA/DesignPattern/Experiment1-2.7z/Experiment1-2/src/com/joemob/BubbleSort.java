package com.joemob;

public class BubbleSort implements Sort{
    @Override
    public void SortNumber() {
        System.out.println("Using bubble sort.");
    }
}
