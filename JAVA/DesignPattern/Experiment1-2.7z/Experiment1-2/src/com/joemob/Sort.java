package com.joemob;

public interface Sort {
    void SortNumber();
}
