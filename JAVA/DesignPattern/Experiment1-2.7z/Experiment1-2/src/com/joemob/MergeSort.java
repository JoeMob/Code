package com.joemob;

public class MergeSort implements Sort{
    @Override
    public void SortNumber() {
        System.out.println("Using merge sort.");
    }
}
