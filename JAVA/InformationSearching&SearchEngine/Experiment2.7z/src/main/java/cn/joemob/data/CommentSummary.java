package cn.joemob.data;

import lombok.Data;

@Data
public class CommentSummary {
    String id;
    String rating;
    String commentCount;
}
