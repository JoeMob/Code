package com.JoeMob.springboot.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ScoreController {
}
