package com.joemob;

public class QuickSort implements Sort{
    @Override
    public void SortNumber() {
        System.out.println("Using quick sort.");
    }
}
