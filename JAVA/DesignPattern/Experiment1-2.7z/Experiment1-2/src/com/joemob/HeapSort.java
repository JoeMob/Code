package com.joemob;

public class HeapSort implements Sort{
    @Override
    public void SortNumber() {
        System.out.println("Using heap sort.");
    }
}
