package cn.joemob.data;

import lombok.Data;

@Data
public class Price {
    String id;
    String price;
}
