package com.JoeMob.springboot.service.impl;

public class ScoreServiceIMPL {
}
