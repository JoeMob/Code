package domain;

public class Sentences {
    String Sentences;
    String User;
    String Sign1;
    String Sign2;
    String Sign3;

    public void setSentences(String a){
        this.Sentences = a;
    }
    public String getSentences(){
        return this.Sentences;
    }
    public void setUser(String a){
        this.User = a;
    }
    public String getUser(){
        return this.User;
    }
    public void setSign1(String a){
        this.Sign1 = a;
    }
    public String getSign1(){
        return this.Sign1;
    }
    public void setSign2(String a){
        this.Sign2 = a;
    }
    public String getSign2(){
        return this.Sign2;
    }
    public void setSign3(String a){
        this.Sign3 = a;
    }
    public String getSign3(){
        return this.Sign3;
    }
}
